/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hermes
 */

@XmlRootElement(name = "tienda")
@XmlAccessorType(XmlAccessType.FIELD)
public class Tienda implements Serializable{
    
    @XmlElement(name = "alimento")
    private ArrayList<Alimento> alimentos = new ArrayList<>();

    public Tienda() {
    }

    public ArrayList<Alimento> getAlimentos() {
        return alimentos;
    }

    public void setAlimentos(ArrayList<Alimento> alimentos) {
        this.alimentos = alimentos;
    }

    @Override
    public String toString() {
        return "Tienda{" + "alimentos=" + alimentos + '}';
    }
    
    
}
