/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Hermes
 */

@XmlRootElement(name = "alimento")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"energia", "grasas", "hidratos", "proteinas"})
public class Nutricion implements Serializable{
    
    @XmlElement(name = "energia")
    private String energia;
    @XmlElement(name = "grasas")
    private String grasas;
    @XmlElement(name = "hidratos")
    private String hidratos;
    @XmlElement(name = "proteinas")
    private String proteinas;

    public Nutricion() {
    }

    public Nutricion(String energia, String grasas, String hidratos, String proteinas) {
        this.energia = energia;
        this.grasas = grasas;
        this.hidratos = hidratos;
        this.proteinas = proteinas;
    }

    public String getEnergia() {
        return energia;
    }

    public void setEnergia(String energia) {
        this.energia = energia;
    }

    public String getGrasas() {
        return grasas;
    }

    public void setGrasas(String grasas) {
        this.grasas = grasas;
    }

    public String getHidratos() {
        return hidratos;
    }

    public void setHidratos(String hidratos) {
        this.hidratos = hidratos;
    }

    public String getProteinas() {
        return proteinas;
    }

    public void setProteinas(String proteinas) {
        this.proteinas = proteinas;
    }

    @Override
    public String toString() {
        return "Nutricion{" + "energia=" + energia + ", grasas=" + grasas + ", hidratos=" + hidratos + ", proteinas=" + proteinas + '}';
    }
    
}
