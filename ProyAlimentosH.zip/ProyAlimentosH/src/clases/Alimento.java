/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Hermes
 */

@XmlRootElement(name = "alimento")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"cod", "descripcion", "marca", "envases", "cantidad", "precio", "nutricion"})
public class Alimento implements Serializable{
    
    @XmlAttribute(name="cod")
    private String cod;
    @XmlElement(name="descripcion")
    private String descripcion;
    @XmlElement(name="marca")
    private String marca;
    @XmlElement(name="envases")
    private String envases;
    @XmlElement(name="cantidad")
    private String cantidad;
    @XmlElement(name="precio")
    private double precio;
    @XmlElement(name="nutricion")
    private Nutricion nutricion = new Nutricion();

    public Alimento() {
    }

    public Alimento(String cod, String descripcion, String marca, String envases, String cantidad, double precio) {
        this.cod = cod;
        this.descripcion = descripcion;
        this.marca = marca;
        this.envases = envases;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public String getCod() {
        return cod;
    }

    public void setCodBarras(String cod) {
        this.cod = cod;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getEnvases() {
        return envases;
    }

    public void setEnvases(String envases) {
        this.envases = envases;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Nutricion getNutricion() {
        return nutricion;
    }

    public void setNutricion(Nutricion nutricion) {
        this.nutricion = nutricion;
    }

    @Override
    public String toString() {
        return "Alimento{" + "cod=" + cod + ", descripcion=" + descripcion + ", marca=" + marca + ", envases=" + envases + ", cantidad=" + cantidad + ", precio=" + precio + ", nutricion=" + nutricion + '}';
    }
    
}
