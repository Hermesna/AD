package app;

import clases.Alimento;
import clases.Tienda;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class ProyAlimentosH {

    public static Tienda leerXml(){
        Tienda tienda = new Tienda();
        try {
            JAXBContext contexto = JAXBContext.newInstance(Tienda.class);
            Unmarshaller unmarshaller = contexto.createUnmarshaller();
            tienda = (Tienda) unmarshaller.unmarshal(new File("./datos/alimentos.xml"));
        } catch (JAXBException e) {
            System.out.println(e.getMessage());
        }
        return tienda;
    }

    public static void mostrarDatosLeidosXML(Tienda tienda) {
        System.out.println("DATOS LEÍDOS DEL ARCHIVO XML");
        System.out.println("============================");
        for (Alimento alimento : tienda.getAlimentos()) {
            System.out.println(alimento.toString());
        }
    }
    
    public static void mostrarDatosConPrecioAumentado(Tienda tienda) {
        System.out.println("DATOS LEÍDOS DEL ARCHIVO XML");
        System.out.println("============================");
        for (Alimento alimento : tienda.getAlimentos()) {
            alimento.setPrecio(Math.round(alimento.getPrecio()) + (alimento.getPrecio() * 0.10));
            System.out.println(alimento.toString());
        }
    }
    
    public static void serializarAJson(Tienda tienda) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try {
            try ( PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("./datos/alimentos.json", false)))) {
                System.out.println("DATOS CONVERTIDOS A JSON");
                System.out.println("============================");
                String cadenasJson = gson.toJson(tienda);
                System.out.println(cadenasJson);
                pw.write(cadenasJson);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) throws JAXBException {

        Tienda tienda = leerXml();

        mostrarDatosLeidosXML(tienda);
        System.out.println("");
        mostrarDatosConPrecioAumentado(tienda);
        System.out.println("");
        serializarAJson(tienda);
    }

}
