package app;

import clases.Agendas;
import clases.Eventos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AppJDBCEventos {

    private static Connection con = null;

    public static void conectarAMySQL(String bd, String usuario, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url;
            url = "jdbc:mysql://localhost:3306/" + bd;
            url += "?autoReconnect=true&useSSL=false&zeroDateTimeBehavior=convertToNull";
            url += "&serverTimezone=UTC";

            con = DriverManager.getConnection(url, usuario, password);

        } catch (SQLException e) {
            System.out.println(e.getErrorCode() + " " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL no accesible");
        }
    }

    public static void desconectarMySQL() {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println(e.getErrorCode() + " " + e.getMessage());
        }
    }

    public static ArrayList<Agendas> cargarAgendasMemoria() {
        String sentenciaSQL = "SELECT codigo, titular, color FROM agendas order by codigo";
        String sentenciaSQL2 = "SELECT fecha, texto, estado FROM eventos";
        Agendas agenda;
        Eventos evento;
        ArrayList<Agendas> listaAgendas = new ArrayList<>();

        try (Statement statement = con.createStatement(); ResultSet rs = statement.executeQuery(sentenciaSQL)) {
            while (rs.next()) {
                agenda = new Agendas(rs.getString("codigo"), rs.getString("titular"), rs.getString("color"));
                listaAgendas.add(agenda);
            }

        } catch (SQLException se) {
            System.out.println(se.getErrorCode() + " " + se.getMessage());
        }
        return listaAgendas;

    }

    public static void mostrarDatos(ArrayList<Agendas> agendas) {

        for (Agendas agenda : agendas) {
            System.out.println("====================================");
            System.out.println("Código.: " + agenda.getCodigo());
            System.out.println("Titular: " + agenda.getTitular());
            System.out.println("Color..: " + agenda.getColor());

            System.out.println("+---------------------+---------------------------+------------+");
            System.out.println("+---------------------+---------------------------+------------+");
        }
    }

    public static void main(String[] args) {
        String usuario = "root";
        String password = "1234";
        String bd = "bdeventos";

        conectarAMySQL(bd, usuario, password);
        ArrayList<Agendas> agendas = cargarAgendasMemoria();
        mostrarDatos(agendas);
        desconectarMySQL();

    }

}
