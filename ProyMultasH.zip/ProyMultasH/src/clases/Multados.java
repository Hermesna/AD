/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hermes
 */

@XmlRootElement(name = "multados")
@XmlAccessorType(XmlAccessType.FIELD)
public class Multados implements Serializable{
    
    @XmlElement(name = "coche")
    private ArrayList<Coche> coches = new ArrayList<>();

    public Multados() {
    }

    public ArrayList<Coche> getCoche() {
        return coches;
    }

    public void setCoche(ArrayList<Coche> coche) {
        this.coches = coche;
    }

    @Override
    public String toString() {
        return "Multados{" + "coche=" + coches + '}';
    }
    
}
