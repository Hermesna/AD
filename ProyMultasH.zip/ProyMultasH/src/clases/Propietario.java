/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Hermes
 */
@XmlRootElement(name = "coche")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"nombre", "email", "telefono"})
public class Propietario implements Serializable {

    @XmlElement(name = "nombre")
    private String nombre;
    @XmlElement(name = "email")
    private String email;
    @XmlElement(name = "telefono")
    private String telefono;

    public Propietario() {
    }

    public Propietario(String nombre, String email, String telefono) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Propietario{" + "nombre=" + nombre + ", email=" + email + ", telefono=" + telefono + '}';
    }
    
}
