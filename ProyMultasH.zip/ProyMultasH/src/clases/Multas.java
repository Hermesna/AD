/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hermes
 */

@XmlRootElement(name = "coche")
@XmlAccessorType(XmlAccessType.FIELD)
public class Multas implements Serializable{
    
    @XmlElement(name = "multa")
    private ArrayList<Multa> multa = new ArrayList<>();

    public Multas() {
    }

    public ArrayList<Multa> getMulta() {
        return multa;
    }

    public void setMulta(ArrayList<Multa> multa) {
        this.multa = multa;
    }

    @Override
    public String toString() {
        return "Multas{" + "multa=" + multa + '}';
    }
    
}
