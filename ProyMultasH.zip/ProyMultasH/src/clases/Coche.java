/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Hermes
 */
@XmlRootElement(name = "coche")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"matricula", "modelo", "motor", "propietario", "multas"})
public class Coche implements Serializable {

    @XmlAttribute(name = "matricula")
    private String matricula;
    @XmlElement(name = "modelo")
    private String modelo;
    @XmlElement(name = "motor")
    private String motor;
    @XmlElement(name = "propietario")
    private Propietario propietario = new Propietario();
    @XmlElement(name = "multas")
    private Multas multas = new Multas();

    public Coche() {
    }

    public Coche(String matricula, String modelo, String motor) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.motor = motor;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }

    public Multas getMultas() {
        return multas;
    }

    public void setMultas(Multas multas) {
        this.multas = multas;
    }

    @Override
    public String toString() {
        return "Coche{" + "matricula=" + matricula + ", modelo=" + modelo + ", motor=" + motor + ", nombre=" + ", propietario=" + propietario + ", multas=" + multas + '}';
    }

}
