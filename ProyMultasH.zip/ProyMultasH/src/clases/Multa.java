/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author Hermes
 */

@XmlRootElement(name = "multas")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"fecha", "hora", "importe"})
public class Multa implements Serializable{

    Date fech = new Date();
    @XmlElement(name = "fecha")
    private String fecha;
    @XmlElement(name = "hora")
    private String hora;
    @XmlElement(name = "importe")
    private Integer importe;

    public Multa() {
    }

    public Multa(String fecha, String hora, Integer importe) {
        this.fecha = fecha;
        this.hora = hora;
        this.importe = importe;
    }

    public String getFecha() {
        return fecha = (new SimpleDateFormat("dd/MM/YYYY")).format(fech);
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Integer getImporte() {
        return importe;
    }

    public void setImporte(Integer importe) {
        this.importe = importe;
    }

    @Override
    public String toString() {
        return "Multa{" + "fecha=" + fecha + ", hora=" + hora + ", importe=" + importe + '}';
    }
    
}
