package app;

import clases.Coche;
import clases.Multados;
import com.csvreader.CsvWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class ProyMultasH {

    public static Multados leerXml() {
        Multados multados = new Multados();
        try {
            JAXBContext contexto = JAXBContext.newInstance(Multados.class);
            Unmarshaller unmarshaller = contexto.createUnmarshaller();
            multados = (Multados) unmarshaller.unmarshal(new File("./datos/bdmultas.xml"));
        } catch (JAXBException e) {
            System.out.println(e.getMessage());
        }
        return multados;
    }

    public static void mostrarDatosLeidosXML(Multados multados) {
        System.out.println("DATOS LEÍDOS DEL ARCHIVO XML");
        System.out.println("============================");
        for (Coche coche : multados.getCoche()) {
            System.out.println(coche.toString());
        }
    }
    
    public static void escribirCSV(Multados multados) throws FileNotFoundException, IOException {
        CsvWriter csvWriter = new CsvWriter(
                new FileOutputStream("./datos/multados.csv", false),
                ',',
                StandardCharsets.UTF_8);
        csvWriter.setDelimiter(',');
        csvWriter.setRecordDelimiter('\n');

        // CABECERA
        String[] cabecera = {"matricula", "modelo", "motor", "nombre", "email", "telefono", "fecha", "hora", "importe"};
        csvWriter.writeRecord(cabecera);

        // DATOS
        // No tengo del todo claro como podria crear el csv aqui ->
        for (Multados multados : multados) {
            String[] datos = multados.getCoche();
            csvWriter.writeRecord(datos);

        }

        csvWriter.close();

        System.out.println("Fichero creado");
    }

    public static void main(String[] args) throws IOException {
        
        Multados multados = leerXml();
        
        mostrarDatosLeidosXML(multados);
        escribirCSV(multados);
    }

}
